<img src="<?=$model['image']['watermark']?>"/>



