<?php 

$routing = [
	'/'=>'index',
	'/index'=>'index',
	'/view'=>'galeria',
	'/historia'=>'historia',
	'/add'=>'add_image',
	'/add_image'=>'add_image',
	'/register'=>'register',
	'/galeria'=>'galeria',
	'/image_view'=>'image_view',
	'/view_selected'=>'view_selected',
	'/search_image'=>'search_image',
];